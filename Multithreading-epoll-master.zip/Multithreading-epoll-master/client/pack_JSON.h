#ifndef PACK_JSON_H_INCLUDED
#define PACK_JSON_H_INCLUDED

void create_udp_package(char * pack, char *ip, char *mac);

void dis_udp_package(char * pack, char *ip, char *mac);

#endif // PACK_JSON_H_INCLUDED
